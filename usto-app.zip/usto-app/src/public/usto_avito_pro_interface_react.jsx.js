import { useMemo, useState } from "react";

export default function UstoAvitoPro() {
  const masters = [
    {
      id: 1,
      name: "Али",
      category: "Электрик",
      rating: 4.9,
      reviews: 32,
      distance: "1.2 км",
      phone: "+992 90 111 22 33",
      price: "от 50 c.",
      avatar: "⚡",
      online: true,
      description: "Монтаж, проводка, ремонт щитков и освещения",
    },
    {
      id: 2,
      name: "Саид",
      category: "Сантехник",
      rating: 4.8,
      reviews: 18,
      distance: "2.4 км",
      phone: "+992 93 333 44 44",
      price: "от 70 c.",
      avatar: "🔧",
      online: false,
      description: "Устранение протечек и установка сантехники",
    },
    {
      id: 3,
      name: "Мухаммад",
      category: "Ремонт телефонов",
      rating: 5.0,
      reviews: 41,
      distance: "0.8 км",
      phone: "+992 95 555 66 66",
      price: "от 40 c.",
      avatar: "📱",
      online: true,
      description: "Замена экранов, аккумуляторов и прошивка",
    },
  ];

  const categories = [
    "Все",
    "Электрик",
    "Сантехник",
    "Ремонт телефонов",
    "Кондиционеры",
    "Строители",
  ];

  const [selectedCategory, setSelectedCategory] = useState("Все");
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState([]);
  const [selectedMaster, setSelectedMaster] = useState(null);

  const filteredMasters = useMemo(() => {
    return masters.filter((master) => {
      const categoryMatch =
        selectedCategory === "Все" ||
        master.category === selectedCategory;

      const searchMatch =
        master.name.toLowerCase().includes(search.toLowerCase()) ||
        master.category.toLowerCase().includes(search.toLowerCase());

      return categoryMatch && searchMatch;
    });
  }, [selectedCategory, search]);

  const toggleFavorite = (id) => {
    setFavorites((prev) =>
      prev.includes(id)
        ? prev.filter((item) => item !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-[#111111] text-white pb-28">
      <div className="sticky top-0 z-20 bg-[#111111]/95 backdrop-blur border-b border-[#222] px-4 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black text-orange-500">УСТО</h1>
            <p className="text-sm text-gray-400">
              Avito для мастеров в Худжанде
            </p>
          </div>

          <button className="bg-orange-500 text-black px-4 py-2 rounded-2xl font-bold">
            + Объявление
          </button>
        </div>

        <input
          type="text"
          placeholder="Найти мастера..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full mt-4 bg-[#1c1c1c] border border-[#2a2a2a] rounded-2xl px-4 py-3 outline-none"
        />
      </div>

      <div className="flex gap-3 overflow-x-auto px-4 py-4">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`whitespace-nowrap px-4 py-2 rounded-2xl border transition ${
              selectedCategory === cat
                ? "bg-orange-500 text-black border-orange-500"
                : "bg-[#1c1c1c] border-[#2a2a2a]"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="mx-4 bg-gradient-to-r from-orange-500 to-yellow-400 text-black rounded-3xl p-5">
        <h2 className="text-2xl font-black">
          Найди мастера за пару минут 👷
        </h2>
        <p className="mt-2 text-sm font-medium">
          Электрики, сантехники, ремонт телефонов и многое другое
        </p>
      </div>

      <div className="p-4 space-y-4">
        {filteredMasters.map((master) => (
          <div
            key={master.id}
            className="bg-[#1a1a1a] rounded-3xl border border-[#252525] p-5"
          >
            <div className="flex justify-between gap-3">
              <div className="flex gap-4">
                <div className="w-16 h-16 rounded-2xl bg-orange-500 flex items-center justify-center text-3xl">
                  {master.avatar}
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-xl font-bold">{master.name}</h3>

                    {master.online && (
                      <span className="bg-green-500/20 text-green-400 text-xs px-2 py-1 rounded-full">
                        Онлайн
                      </span>
                    )}
                  </div>

                  <p className="text-gray-400 text-sm mt-1">
                    {master.category}
                  </p>

                  <div className="flex gap-2 mt-2 flex-wrap text-sm">
                    <span className="bg-[#222] px-2 py-1 rounded-xl">
                      ⭐ {master.rating}
                    </span>
                    <span className="text-gray-400">
                      📍 {master.distance}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => toggleFavorite(master.id)}
                className="text-2xl"
              >
                {favorites.includes(master.id) ? "❤️" : "🤍"}
              </button>
            </div>

            <div className="mt-4 bg-[#222] rounded-2xl p-4">
              <p className="text-sm text-gray-300">
                {master.description}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="bg-[#222] rounded-2xl p-3">
                <p className="text-xs text-gray-400">Цена</p>
                <p className="font-bold text-lg">{master.price}</p>
              </div>

              <div className="bg-[#222] rounded-2xl p-3">
                <p className="text-xs text-gray-400">Телефон</p>
                <p className="font-bold text-sm mt-1">{master.phone}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-5">
              <a
                href={`tel:${master.phone}`}
                className="bg-orange-500 text-black py-3 rounded-2xl font-bold text-center"
              >
                📞
              </a>

              <button className="bg-[#252525] py-3 rounded-2xl font-bold border border-[#333]">
                💬
              </button>

              <button
                onClick={() => setSelectedMaster(master)}
                className="bg-[#252525] py-3 rounded-2xl font-bold border border-[#333]"
              >
                Подробнее
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedMaster && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-end md:items-center justify-center p-4">
          <div className="bg-[#1a1a1a] w-full max-w-md rounded-3xl p-6 border border-[#2a2a2a]">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-black">Профиль мастера</h2>

              <button
                onClick={() => setSelectedMaster(null)}
                className="text-2xl"
              >
                ✖
              </button>
            </div>

            <div className="text-center mt-5">
              <div className="w-24 h-24 mx-auto rounded-3xl bg-orange-500 flex items-center justify-center text-5xl">
                {selectedMaster.avatar}
              </div>

              <h3 className="text-2xl font-bold mt-4">
                {selectedMaster.name}
              </h3>

              <p className="text-gray-400 mt-1">
                {selectedMaster.category}
              </p>
            </div>

            <div className="bg-[#222] rounded-2xl p-4 mt-5">
              <p className="text-sm text-gray-300 leading-relaxed">
                {selectedMaster.description}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-5">
              <a
                href={`tel:${selectedMaster.phone}`}
                className="bg-orange-500 text-black py-3 rounded-2xl font-bold text-center"
              >
                📞 Позвонить
              </a>

              <button className="bg-[#252525] py-3 rounded-2xl font-bold border border-[#333]">
                💬 Написать
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-[#111111]/95 border-t border-[#222] px-4 py-3">
        <div className="grid grid-cols-4 gap-2 text-center">
          <button className="bg-orange-500 text-black py-3 rounded-2xl font-bold">
            🏠
          </button>

          <button className="bg-[#1c1c1c] py-3 rounded-2xl">
            🔍
          </button>

          <button className="bg-[#1c1c1c] py-3 rounded-2xl">
            ❤️
          </button>

          <button className="bg-[#1c1c1c] py-3 rounded-2xl">
            👤
          </button>
        </div>
      </div>
    </div>
  );
}
